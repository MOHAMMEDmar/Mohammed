import { Link, useRouterState } from "@tanstack/react-router";
import { Leaf, Menu, X } from "lucide-react";
import { useState } from "react";

const links = [
  { to: "/", label: "Home" },
  { to: "/pulse", label: "Pulse" },
  { to: "/foodroute", label: "FoodRoute" },
  { to: "/aquaflow", label: "AquaFlow" },
  { to: "/wearshare", label: "WearShare" },
  { to: "/techcycle", label: "TechCycle" },
  { to: "/ecokids", label: "EcoKids" },
  { to: "/campaigns", label: "Campaigns" },
  { to: "/dashboard", label: "Dashboard" },
] as const;

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-50 glass">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="grid h-9 w-9 place-items-center rounded-xl gradient-hero shadow-glow">
            <Leaf className="h-5 w-5 text-white" />
          </div>
          <div className="leading-tight">
            <div className="font-display text-lg font-bold tracking-tight">Catalyst</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Abu Dhabi</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {links.map((l) => {
            const active = path === l.to;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`rounded-full px-3 py-1.5 text-sm font-medium transition ${
                  active
                    ? "bg-primary/10 text-primary"
                    : "text-foreground/70 hover:text-foreground hover:bg-muted"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden lg:flex items-center gap-2">
          <Link
            to="/dashboard"
            className="rounded-full gradient-hero px-4 py-2 text-sm font-semibold text-white shadow-glow hover:opacity-95"
          >
            Join Catalyst
          </Link>
        </div>

        <button
          className="lg:hidden grid h-9 w-9 place-items-center rounded-lg border border-border"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t border-border bg-card/95 backdrop-blur">
          <div className="mx-auto max-w-7xl px-4 py-3 grid gap-1">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className={`rounded-lg px-3 py-2 text-sm font-medium ${
                  path === l.to ? "bg-primary/10 text-primary" : "hover:bg-muted"
                }`}
              >
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t border-border bg-card/40">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 grid gap-8 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-lg gradient-hero">
              <Leaf className="h-4 w-4 text-white" />
            </div>
            <span className="font-display text-base font-bold">Catalyst</span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Connecting Surplus. Creating Impact. An AI-powered sustainability platform for Abu Dhabi.
          </p>
        </div>
        <div>
          <div className="text-sm font-semibold mb-3">Modules</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/foodroute" className="hover:text-foreground">FoodRoute</Link></li>
            <li><Link to="/aquaflow" className="hover:text-foreground">AquaFlow</Link></li>
            <li><Link to="/wearshare" className="hover:text-foreground">WearShare</Link></li>
            <li><Link to="/techcycle" className="hover:text-foreground">TechCycle</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-sm font-semibold mb-3">Community</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/ecokids" className="hover:text-foreground">EcoKids Zone</Link></li>
            <li><Link to="/campaigns" className="hover:text-foreground">Campaign Hub</Link></li>
            <li><Link to="/pulse" className="hover:text-foreground">Catalyst Pulse</Link></li>
            <li><Link to="/dashboard" className="hover:text-foreground">My Dashboard</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-sm font-semibold mb-3">Partners</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Abu Dhabi Municipality</li>
            <li>Emirates Red Crescent</li>
            <li>EAD · Tadweer</li>
            <li>UAE Food Bank</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
        © 2026 Catalyst · Built for a more sustainable Abu Dhabi 🌱
      </div>
    </footer>
  );
}
