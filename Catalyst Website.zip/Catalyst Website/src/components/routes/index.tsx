import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Apple, Droplets, Shirt, Cpu, Sparkles, Megaphone, ArrowRight,
  Leaf, Users, TrendingUp, MapPin, Star, BookOpen, Recycle, Heart,
} from "lucide-react";
import { PulseMap } from "../components/pulse-map";
import { LineChart, Line, ResponsiveContainer, AreaChart, Area, Tooltip, XAxis } from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Catalyst · Connecting Surplus. Creating Impact." },
      { name: "description", content: "AI-powered sustainability platform for Abu Dhabi. Route surplus food, water, clothes, books, and electronics to where they matter most." },
      { property: "og:title", content: "Catalyst · Sustainability Platform for Abu Dhabi" },
      { property: "og:description", content: "Live AI heatmap, smart routing, gamified impact." },
    ],
  }),
  component: Landing,
});

const MODULES = [
  { to: "/foodroute", icon: Apple, name: "FoodRoute", tag: "Surplus → Shelters", desc: "AI matches surplus food from restaurants & hotels with nearby shelters in real time.", color: "oklch(0.62 0.16 155)" },
  { to: "/aquaflow", icon: Droplets, name: "AquaFlow", tag: "Smart water routing", desc: "Report leaks, shortages, and surplus. AI recommends efficient distribution.", color: "oklch(0.55 0.14 230)" },
  { to: "/wearshare", icon: Shirt, name: "WearShare", tag: "Donations marketplace", desc: "AI image recognition identifies items. Smart matching by urgency and distance.", color: "oklch(0.68 0.14 320)" },
  { to: "/techcycle", icon: Cpu, name: "TechCycle", tag: "Electronics rehoming", desc: "Rehome laptops, phones, and tablets to schools, students, and repair centers.", color: "oklch(0.65 0.16 60)" },
  { to: "/ecokids", icon: Sparkles, name: "EcoKids Zone", tag: "Learn · Play · Win", desc: "Eco-challenges, quizzes, badges, and school-vs-school leaderboards.", color: "oklch(0.78 0.16 95)" },
  { to: "/campaigns", icon: Megaphone, name: "Campaign Hub", tag: "Act together", desc: "Tree planting, cleanups, food rescues. AI suggests campaigns for you.", color: "oklch(0.68 0.20 25)" },
];

const TRENDS = Array.from({ length: 24 }, (_, i) => ({
  h: `${i}:00`,
  rescued: 40 + Math.round(Math.sin(i / 3) * 18 + Math.random() * 14 + i * 1.5),
  donated: 20 + Math.round(Math.cos(i / 4) * 10 + Math.random() * 8 + i),
}));

function useCounter(target: number, ms = 1400) {
  const [v, setV] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / ms);
      setV(Math.round(target * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return v;
}

function Landing() {
  const meals = useCounter(248531);
  const water = useCounter(1820000);
  const items = useCounter(94128);
  const co2 = useCounter(1342);

  return (
    <div>
      {/* HERO */}
      <section className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-10 sm:pt-16 pb-10">
        <div className="grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:items-center">
          <div className="min-w-0">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary uppercase tracking-wider">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-75 animate-ping" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              Live · Abu Dhabi
            </div>
            <h1 className="mt-4 font-display text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight leading-[1.02]">
              Connecting <span className="gradient-text">Surplus.</span><br />
              Creating <span className="gradient-text">Impact.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base sm:text-lg text-muted-foreground">
              Catalyst is an AI-powered sustainability ecosystem that routes surplus food, water, clothes, books, and electronics to where they're needed most — in real time across Abu Dhabi.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/dashboard" className="inline-flex items-center gap-1.5 rounded-full gradient-hero text-white px-6 py-3 text-sm font-semibold shadow-glow hover:opacity-95">
                Join the movement <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/pulse" className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold hover:bg-muted">
                <MapPin className="h-4 w-4 text-primary" /> Explore Pulse
              </Link>
            </div>

            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <LiveStat icon={Apple} v={meals.toLocaleString()} label="Meals rescued" />
              <LiveStat icon={Droplets} v={`${(water/1000).toFixed(0)}k L`} label="Water saved" />
              <LiveStat icon={Heart} v={items.toLocaleString()} label="Items rehomed" />
              <LiveStat icon={Leaf} v={`${co2.toLocaleString()}t`} label="CO₂ prevented" />
            </div>
          </div>

          <div className="relative">
            <PulseMap height={460} />
            <div className="absolute -bottom-6 -left-4 sm:-left-8 glass rounded-2xl px-4 py-3 shadow-glow flex items-center gap-3 animate-float">
              <div className="grid h-10 w-10 place-items-center rounded-xl gradient-hero text-white">
                <Sparkles className="h-5 w-5" />
              </div>
              <div className="text-xs">
                <div className="font-semibold">AI matched 12 rescues</div>
                <div className="text-muted-foreground">in the last 60 seconds</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MODULES */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <SectionHeading eyebrow="The Catalyst Ecosystem" title="Six modules. One mission." sub="Each module handles a category of surplus and uses AI to route it where it matters." />
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map((m) => (
            <Link key={m.to} to={m.to} className="group relative overflow-hidden rounded-3xl glass shadow-card p-6 hover:-translate-y-1 transition">
              <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full blur-2xl opacity-30" style={{ background: m.color }} />
              <div className="relative">
                <div className="grid h-12 w-12 place-items-center rounded-2xl text-white shadow-glow" style={{ background: m.color }}>
                  <m.icon className="h-6 w-6" />
                </div>
                <div className="mt-4 text-xs uppercase tracking-wider text-muted-foreground">{m.tag}</div>
                <div className="font-display text-xl font-bold mt-1">{m.name}</div>
                <p className="mt-2 text-sm text-muted-foreground">{m.desc}</p>
                <div className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Open module <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* IMPACT TRENDS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <SectionHeading eyebrow="Live Impact" title="Abu Dhabi, in motion." sub="A 24-hour view of resources rescued and donated city-wide." />
        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          <div className="lg:col-span-2 glass rounded-3xl p-5 shadow-card">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Last 24 hours</div>
                <div className="font-display text-xl font-bold">Rescued vs Donated</div>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-primary"/>Rescued</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-secondary"/>Donated</span>
              </div>
            </div>
            <div className="h-64 mt-4">
              <ResponsiveContainer>
                <AreaChart data={TRENDS}>
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--secondary)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="var(--secondary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="h" tick={{ fontSize: 10, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--border)", background: "var(--card)" }} />
                  <Area type="monotone" dataKey="rescued" stroke="var(--primary)" fill="url(#g1)" strokeWidth={2.5} />
                  <Area type="monotone" dataKey="donated" stroke="var(--secondary)" fill="url(#g2)" strokeWidth={2.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid gap-4">
            <MiniTrend label="Sustainability Score" value="842" delta="+12 this week" data={[60,64,62,70,72,80,84]} />
            <MiniTrend label="Active volunteers" value="3,420" delta="+218 today" data={[20,28,26,40,52,60,72]} color="var(--secondary)" />
            <MiniTrend label="Tons of waste diverted" value="1,342" delta="+38 today" data={[10,18,22,28,35,42,50]} color="var(--coral)" />
          </div>
        </div>
      </section>

      {/* CAMPAIGNS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <SectionHeading eyebrow="Campaign Catalyst Hub" title="Join an active campaign." sub="AI-recommended by interest, age, and location." />
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CAMPAIGNS.map((c) => (
            <div key={c.title} className="glass rounded-3xl overflow-hidden shadow-card hover:-translate-y-1 transition">
              <div className="h-32 relative" style={{ background: c.gradient }}>
                <div className="absolute inset-0 grid place-items-center text-white/90">
                  <c.icon className="h-14 w-14" />
                </div>
                <div className="absolute top-3 left-3 glass rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider">
                  {c.tag}
                </div>
              </div>
              <div className="p-5">
                <div className="font-display font-bold">{c.title}</div>
                <div className="text-xs text-muted-foreground mt-1">{c.where} · {c.when}</div>
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                    <span>{c.volunteers} volunteers</span><span>{c.pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div className="h-full gradient-hero rounded-full" style={{ width: `${c.pct}%` }} />
                  </div>
                </div>
                <button className="mt-4 w-full rounded-full gradient-hero text-white py-2 text-sm font-semibold">Join campaign</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <SectionHeading eyebrow="Trusted by" title="A coalition for Abu Dhabi." />
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <div key={t.who} className="glass rounded-3xl p-6 shadow-card">
              <div className="flex gap-0.5 text-[oklch(0.82_0.16_85)]">
                {Array.from({length: 5}).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-3 text-sm leading-relaxed">"{t.quote}"</p>
              <div className="mt-4 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full gradient-hero text-white font-bold">{t.who[0]}</div>
                <div>
                  <div className="text-sm font-semibold">{t.who}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-muted-foreground">
          {PARTNERS.map((p) => (
            <div key={p} className="font-display font-bold tracking-tight text-base opacity-70 hover:opacity-100 transition">{p}</div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <div className="relative overflow-hidden rounded-3xl gradient-hero p-8 sm:p-14 text-white shadow-glow">
          <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
          <div className="relative grid gap-6 md:grid-cols-[1.4fr_1fr] md:items-center">
            <div>
              <h2 className="font-display text-3xl sm:text-5xl font-black">Be a catalyst.</h2>
              <p className="mt-3 text-white/90 max-w-xl">Sign up as a citizen, student, business, NGO, or volunteer. Catalyst routes your surplus and contributions to maximum impact.</p>
            </div>
            <div className="flex flex-wrap gap-3 md:justify-end">
              <Link to="/dashboard" className="rounded-full bg-white text-primary px-6 py-3 text-sm font-bold shadow-card">Create account</Link>
              <Link to="/campaigns" className="rounded-full border border-white/40 bg-white/10 px-6 py-3 text-sm font-bold backdrop-blur">Browse campaigns</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function LiveStat({ icon: Icon, v, label }: { icon: typeof Apple; v: string; label: string }) {
  return (
    <div className="glass rounded-2xl p-3 shadow-card">
      <div className="flex items-center gap-2">
        <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary"><Icon className="h-4 w-4" /></div>
        <div className="min-w-0">
          <div className="font-display text-lg font-black leading-none truncate">{v}</div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
        </div>
      </div>
    </div>
  );
}

function SectionHeading({ eyebrow, title, sub }: { eyebrow: string; title: string; sub?: string }) {
  return (
    <div className="max-w-2xl">
      <div className="text-xs uppercase tracking-widest text-primary font-semibold">{eyebrow}</div>
      <h2 className="mt-2 font-display text-3xl sm:text-4xl font-black tracking-tight">{title}</h2>
      {sub && <p className="mt-2 text-muted-foreground">{sub}</p>}
    </div>
  );
}

function MiniTrend({ label, value, delta, data, color = "var(--primary)" }: { label: string; value: string; delta: string; data: number[]; color?: string }) {
  const points = data.map((y, i) => ({ i, y }));
  return (
    <div className="glass rounded-2xl p-4 shadow-card">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
          <div className="font-display text-2xl font-black">{value}</div>
          <div className="text-xs text-primary flex items-center gap-1"><TrendingUp className="h-3 w-3" />{delta}</div>
        </div>
        <div className="h-14 w-28">
          <ResponsiveContainer>
            <LineChart data={points}>
              <Line type="monotone" dataKey="y" stroke={color} strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

const CAMPAIGNS = [
  { title: "Mangrove Planting Drive", tag: "Tree Planting", where: "Jubail Mangroves", when: "Sat, 9 Jul", volunteers: 124, pct: 72, icon: Leaf, gradient: "linear-gradient(135deg,oklch(0.62 0.16 155),oklch(0.48 0.10 195))" },
  { title: "Corniche Beach Cleanup", tag: "Cleanup", where: "Corniche", when: "Fri, 8 Jul", volunteers: 318, pct: 88, icon: Recycle, gradient: "linear-gradient(135deg,oklch(0.55 0.14 230),oklch(0.62 0.16 200))" },
  { title: "Iftar Food Rescue", tag: "Food Rescue", where: "City-wide", when: "Daily · Ramadan", volunteers: 612, pct: 64, icon: Apple, gradient: "linear-gradient(135deg,oklch(0.68 0.20 25),oklch(0.78 0.16 60))" },
  { title: "Books for Every Child", tag: "Donation", where: "Mussafah Schools", when: "Sun, 10 Jul", volunteers: 84, pct: 45, icon: BookOpen, gradient: "linear-gradient(135deg,oklch(0.65 0.16 60),oklch(0.78 0.16 95))" },
  { title: "Save-the-Drop Challenge", tag: "Water", where: "Citywide schools", when: "Aug · 2 weeks", volunteers: 1820, pct: 58, icon: Droplets, gradient: "linear-gradient(135deg,oklch(0.55 0.14 230),oklch(0.72 0.14 200))" },
  { title: "E-Waste Roadshow", tag: "Recycle", where: "Yas Mall", when: "Sat, 16 Jul", volunteers: 96, pct: 30, icon: Cpu, gradient: "linear-gradient(135deg,oklch(0.48 0.10 195),oklch(0.62 0.16 155))" },
];

const TESTIMONIALS = [
  { who: "Aisha Al Mansoori", role: "Volunteer · Khalifa City", quote: "Catalyst turned my weekends into something meaningful. I've helped rescue over 400kg of food this month." },
  { who: "Chef Karim", role: "Hilton Abu Dhabi", quote: "We post surplus after every banquet. Within 30 minutes, a verified NGO is at our door. It's beautifully simple." },
  { who: "Mariam Saleh", role: "Teacher · Al Reem Academy", quote: "My class climbed the EcoKids leaderboard. The kids genuinely care about sustainability now." },
];

const PARTNERS = ["Abu Dhabi Municipality", "EAD", "Tadweer", "Emirates Red Crescent", "UAE Food Bank", "Masdar", "ADNOC Sustainability"];
