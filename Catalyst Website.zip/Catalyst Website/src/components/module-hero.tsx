import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

export function ModuleHero({
  eyebrow,
  title,
  description,
  accent,
  icon,
}: {
  eyebrow: string;
  title: string;
  description: string;
  accent: string; // css color
  icon: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden rounded-3xl glass shadow-card p-6 sm:p-10">
      <div
        className="absolute -top-20 -right-20 h-72 w-72 rounded-full blur-3xl opacity-40"
        style={{ background: accent }}
      />
      <div className="relative grid gap-6 md:grid-cols-[1fr_auto] md:items-end">
        <div className="min-w-0">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary uppercase tracking-wider">
            {eyebrow}
          </div>
          <h1 className="mt-3 font-display text-3xl sm:text-5xl font-black tracking-tight">{title}</h1>
          <p className="mt-3 max-w-2xl text-base text-muted-foreground">{description}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/dashboard" className="inline-flex items-center gap-1.5 rounded-full gradient-hero text-white px-5 py-2.5 text-sm font-semibold shadow-glow">
              Get started <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/pulse" className="inline-flex items-center rounded-full border border-border bg-card px-5 py-2.5 text-sm font-semibold hover:bg-muted">
              View on Pulse
            </Link>
          </div>
        </div>
        <div
          className="grid h-28 w-28 sm:h-36 sm:w-36 place-items-center rounded-3xl shadow-glow text-white shrink-0"
          style={{ background: accent }}
        >
          <div className="[&_svg]:h-14 [&_svg]:w-14 sm:[&_svg]:h-20 sm:[&_svg]:w-20">{icon}</div>
        </div>
      </div>
    </section>
  );
}

export function StatCard({ label, value, sub, accent = "var(--primary)" }: { label: string; value: string; sub?: string; accent?: string }) {
  return (
    <div className="glass rounded-2xl p-5 shadow-card">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-3xl font-black" style={{ color: accent }}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}
