import { useEffect, useState } from "react";

export type PulseNode = {
  id: string;
  x: number; // 0-100 %
  y: number; // 0-100 %
  type: "food" | "water" | "clothes" | "books" | "electronics" | "recycle";
  status: "urgent" | "moderate" | "resolved";
  label: string;
  detail: string;
};

const TYPE_FILTERS = [
  { id: "all", label: "All" },
  { id: "food", label: "Food" },
  { id: "water", label: "Water" },
  { id: "clothes", label: "Clothes" },
  { id: "books", label: "Books" },
  { id: "electronics", label: "Electronics" },
  { id: "recycle", label: "Recycle" },
] as const;

const STATUS_COLOR: Record<PulseNode["status"], string> = {
  urgent: "oklch(0.65 0.22 25)",
  moderate: "oklch(0.82 0.16 85)",
  resolved: "oklch(0.62 0.16 155)",
};

export const SAMPLE_NODES: PulseNode[] = [
  { id: "n1", x: 22, y: 38, type: "food", status: "urgent", label: "Al Bateen", detail: "180kg surplus from 4 hotels" },
  { id: "n2", x: 34, y: 52, type: "water", status: "urgent", label: "Mussafah", detail: "Leak reported · 3 buildings" },
  { id: "n3", x: 46, y: 30, type: "clothes", status: "moderate", label: "Khalifa City", detail: "Donation drive active" },
  { id: "n4", x: 58, y: 44, type: "electronics", status: "moderate", label: "Reem Island", detail: "32 laptops awaiting pickup" },
  { id: "n5", x: 68, y: 60, type: "books", status: "resolved", label: "Yas Island", detail: "1,200 books delivered" },
  { id: "n6", x: 40, y: 68, type: "recycle", status: "moderate", label: "Khalidiya", detail: "E-waste collection live" },
  { id: "n7", x: 76, y: 32, type: "food", status: "resolved", label: "Saadiyat", detail: "Route optimized · 95% saved" },
  { id: "n8", x: 18, y: 58, type: "water", status: "moderate", label: "Corniche", detail: "Conservation campaign" },
  { id: "n9", x: 52, y: 76, type: "clothes", status: "urgent", label: "Mohammed Bin Zayed City", detail: "Urgent: 400 families" },
  { id: "n10", x: 30, y: 22, type: "electronics", status: "resolved", label: "Marina Mall", detail: "65 devices rehomed" },
  { id: "n11", x: 64, y: 22, type: "food", status: "urgent", label: "Al Maryah", detail: "Restaurant surplus · 90min" },
  { id: "n12", x: 82, y: 50, type: "books", status: "moderate", label: "Al Raha", detail: "School supplies needed" },
];

export function PulseMap({ height = 520 }: { height?: number }) {
  const [filter, setFilter] = useState<string>("all");
  const [active, setActive] = useState<PulseNode | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 2200);
    return () => clearInterval(i);
  }, []);

  const nodes = SAMPLE_NODES.filter((n) => filter === "all" || n.type === filter);

  return (
    <div className="glass rounded-3xl p-4 sm:p-6 shadow-card">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-75 animate-ping" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-primary" />
            </span>
            <h3 className="font-display text-lg font-bold">Catalyst Pulse · Abu Dhabi</h3>
          </div>
          <p className="text-xs text-muted-foreground">Live AI heatmap · updated {tick}s ago</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {TYPE_FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`rounded-full px-3 py-1 text-xs font-medium transition ${
                filter === f.id
                  ? "gradient-hero text-white shadow-glow"
                  : "bg-muted text-muted-foreground hover:bg-accent"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div
        className="relative w-full overflow-hidden rounded-2xl border border-border"
        style={{
          height,
          backgroundImage: `
            radial-gradient(ellipse at 20% 40%, oklch(0.62 0.16 155 / 0.18), transparent 40%),
            radial-gradient(ellipse at 70% 30%, oklch(0.55 0.14 230 / 0.20), transparent 45%),
            radial-gradient(ellipse at 50% 80%, oklch(0.82 0.16 85 / 0.14), transparent 45%),
            linear-gradient(180deg, oklch(0.96 0.02 200), oklch(0.93 0.03 210))
          `,
        }}
      >
        {/* fake street grid */}
        <svg className="absolute inset-0 h-full w-full opacity-40" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="oklch(0.55 0.05 210)" strokeWidth="0.4" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          {/* coastline curves */}
          <path d="M 0 380 Q 200 320 400 360 T 800 340 L 800 520 L 0 520 Z" fill="oklch(0.55 0.14 230 / 0.18)" />
          <path d="M 600 80 Q 700 140 720 220 Q 700 280 640 300 L 600 240 Z" fill="oklch(0.55 0.14 230 / 0.18)" />
        </svg>

        {/* nodes */}
        {nodes.map((n) => (
          <button
            key={n.id}
            onClick={() => setActive(n)}
            className="absolute -translate-x-1/2 -translate-y-1/2 group"
            style={{ left: `${n.x}%`, top: `${n.y}%` }}
          >
            <span
              className="absolute inset-0 m-auto h-4 w-4 rounded-full animate-pulse-ring"
              style={{ backgroundColor: STATUS_COLOR[n.status], opacity: 0.5 }}
            />
            <span
              className="relative block h-4 w-4 rounded-full ring-2 ring-white shadow-md transition group-hover:scale-150"
              style={{ backgroundColor: STATUS_COLOR[n.status] }}
            />
          </button>
        ))}

        {/* legend */}
        <div className="absolute bottom-3 left-3 glass rounded-xl px-3 py-2 text-xs flex items-center gap-3">
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full" style={{background: STATUS_COLOR.urgent}}/>Urgent</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full" style={{background: STATUS_COLOR.moderate}}/>Moderate</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full" style={{background: STATUS_COLOR.resolved}}/>Resolved</span>
        </div>

        {/* AI forecast badge */}
        <div className="absolute top-3 right-3 glass rounded-xl px-3 py-2 text-xs max-w-[220px]">
          <div className="font-semibold text-primary">AI Forecast</div>
          <div className="text-muted-foreground">Food waste spike predicted in Al Bateen at 21:00 — pre-routing volunteers.</div>
        </div>

        {/* node detail card */}
        {active && (
          <div
            className="absolute glass rounded-2xl p-4 shadow-glow w-64 z-10"
            style={{
              left: `min(${active.x}%, calc(100% - 17rem))`,
              top: `min(${active.y + 4}%, calc(100% - 9rem))`,
            }}
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{active.type}</div>
                <div className="font-display font-bold">{active.label}</div>
              </div>
              <button onClick={() => setActive(null)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <p className="mt-1 text-sm">{active.detail}</p>
            <div className="mt-3 flex gap-2">
              <button className="flex-1 rounded-lg gradient-hero text-white text-xs font-semibold py-1.5">Dispatch</button>
              <button className="rounded-lg border border-border text-xs font-semibold py-1.5 px-3">Details</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
